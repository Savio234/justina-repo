// import React, { useState }  from 'react'

// const ImageSlider: React.FC = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const slideStyles = {
//     width: "100%",

//   }
  
//   return (
   
//     <div>
//     <div style= {{backgroundImage: url }}>
//     </div>
//   )
// }

// export default ImageSlider

